import json
import psycopg2
import bcrypt
import boto3

def get_secret(secret_name, region_name="us-east-1"):
    client = boto3.client("secretsmanager", region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response["SecretString"])


def lambda_handler(event, context):
    # Get DB credentials
    try:
        secret = get_secret("dermis/dbconfig")
        POSTGRES_DB_HOST = secret["POSTGRES_DB_HOST"]
        POSTGRES_DB_PORT = int(secret.get("POSTGRES_DB_PORT", "5432"))  # Default to 5432 if not set
        POSTGRES_DB_NAME = secret["POSTGRES_DB_NAME"]
        POSTGRES_DB_USER = secret["POSTGRES_DB_USER"]
        POSTGRES_DB_PASSWORD = secret["POSTGRES_DB_PASSWORD"]
    except Exception as secret_err:
        print("Failed to retrieve DB credentials:", str(secret_err))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Failed to get DB credentials'})
        }
    print("DB credentials retrieved successfully")
    http_method = event.get('requestContext', {}).get('http', {}).get('method', 'POST')
    print(f"HTTP method: {http_method}")

    if http_method != 'POST':
        print("Invalid method")
        return {
            'statusCode': 405,
            'body': json.dumps({'error': 'Method not allowed'})
        }

    try:
        data = json.loads(event['body'])
        email = data.get('email')
        password = data.get('password')

        print(f"Received email: {email}")
        print(f"Password present: {bool(password)}")

        if not email or not password:
            print("Missing email or password")
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Email and password are required'})
            }

        print("Connecting to DB...")
        conn = psycopg2.connect(
            host=POSTGRES_DB_HOST,
            dbname=POSTGRES_DB_NAME,
            user=POSTGRES_DB_USER,
            password=POSTGRES_DB_PASSWORD,
            port=POSTGRES_DB_PORT
        )
        cursor = conn.cursor()
        print("Connected to DB")

        print("Querying user by email...")
        cursor.execute("""
            SELECT user_id, password FROM users WHERE email = %s
        """, (email,))
        result = cursor.fetchone()

        cursor.close()
        conn.close()

        if not result:
            print("User not found")
            return {
                'statusCode': 401,
                'body': json.dumps({'error': 'Invalid email or password'})
            }

        user_id, stored_hash = result
        print(f"User found: {user_id}")
        print(f"Stored hash: {stored_hash}")

        password_match = bcrypt.checkpw(password.encode('utf-8'), stored_hash.encode('utf-8'))
        print(f"Password match: {password_match}")

        if password_match:
            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'Login successful', 'user_id': user_id})
            }
        else:
            return {
                'statusCode': 401,
                'body': json.dumps({'error': 'Invalid email or password'})
            }

    except Exception as e:
        print(f"Error during execution: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
