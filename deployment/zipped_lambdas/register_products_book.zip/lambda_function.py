import json
import uuid
import psycopg2
import boto3

def get_secret(secret_name, region_name="us-east-1"):
    client = boto3.client("secretsmanager", region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response["SecretString"])


def lambda_handler(event, context):
    #pasar todos los productos/book de los libros al postgres
    if 'requestContext' in event and 'http' in event['requestContext']:
        http_method = event['requestContext']['http']['method']
    else:
        http_method = 'POST'

    # Get DB credentials
    try:
        secret = get_secret("dermis/dbconfig")
        POSTGRES_DB_HOST = secret["POSTGRES_DB_HOST"]
        POSTGRES_DB_PORT = int(secret.get("POSTGRES_DB_PORT", "5432"))  # Default to 5432 if not set
        POSTGRES_DB_NAME = secret["POSTGRES_DB_NAME"]
        POSTGRES_DB_USER = secret["POSTGRES_DB_USER"]
        POSTGRES_DB_PASSWORD = secret["POSTGRES_DB_PASSWORD"]
    except Exception as secret_err:
        print("Failed to retrieve DB credentials:", str(secret_err))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Failed to get DB credentials'})
        } 

    if http_method == 'POST':
            print("entro en post")
            data = json.loads(event['body'])
            product_id = str(uuid.uuid4())

            try:
                conn = psycopg2.connect(
                    host=POSTGRES_DB_HOST,
                    dbname=POSTGRES_DB_NAME,
                    user=POSTGRES_DB_USER,
                    password=POSTGRES_DB_PASSWORD,
                    port=POSTGRES_DB_PORT
                )
                print("se conectó a la bd")
                cursor = conn.cursor()

                #recordar q es tabla de productos del libro
                cursor.execute("""
                    INSERT INTO products_book (product_id, name, skyn_type4, ingredients)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """, (
                    product_id,
                    data.get('name'),
                    data.get('skyn_type4'),
                    data.get('ingredients')
                ))

                conn.commit()
                cursor.close()
                conn.close()

                return {
                    'statusCode': 200,
                    'body': json.dumps({'message': 'Product_book now in', 'product_id': product_id})
                }

            except Exception as e:
                return {
                    'statusCode': 500,
                    'body': json.dumps({'error': str(e)})
                }
    
    #para obtener todos los productos de un tipo compuesto en especifico
    #get
    if http_method == 'GET':
        
        data = json.loads(event['body'])
        #compuest_confition
        compuest_condition = data['compuest_condition']
        #me conecto y voy colectando los prodds q cumplan
        try:
                conn = psycopg2.connect(
                    host=POSTGRES_DB_HOST,
                    dbname=POSTGRES_DB_NAME,
                    user=POSTGRES_DB_USER,
                    password=POSTGRES_DB_PASSWORD,
                    port=POSTGRES_DB_PORT
                )
                print("se conectó a la bd")
                cursor = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
                cursor.execute("""
                    SELECT * FROM products_book
                    WHERE skyn_type4 = %s
                """, (compuest_condition,))
                products = [dict(row) for row in cursor.fetchall()]

                #recordar q es tabla de productos del libro


                #escritura no conn.commit()
                cursor.close()
                conn.close()

                return {
                    'statusCode': 200,
                    'body': json.dumps({'message': 'Products for that condition founded', 'products': products})
                }

        except Exception as e:
                return {
                    'statusCode': 500,
                    'body': json.dumps({'error': str(e)})
                }
         



    else:
         return {
            'statusCode': 405,
            'body': json.dumps({'error': 'Method not allowed'})
        }