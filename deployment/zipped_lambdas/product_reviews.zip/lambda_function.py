import json
import psycopg2
import logging
import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_secret(secret_name, region_name="us-east-1"):
    client = boto3.client("secretsmanager", region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response["SecretString"])


def lambda_handler(event, context):
    http_method = event.get('requestContext', {}).get('http', {}).get('method', 'POST')
    logger.info(f"Incoming event: {json.dumps(event)}")
    # Get DB credentials
    try:
        secret = get_secret("dermis/dbconfig")
        POSTGRES_DB_HOST = secret["POSTGRES_DB_HOST"]
        POSTGRES_DB_PORT = int(secret.get("POSTGRES_DB_PORT", "5432"))  # Default to 5432 if not set
        POSTGRES_DB_NAME = secret["POSTGRES_DB_NAME"]
        POSTGRES_DB_USER = secret["POSTGRES_DB_USER"]
        POSTGRES_DB_PASSWORD = secret["POSTGRES_DB_PASSWORD"]
    except Exception as secret_err:
        print("Failed to retrieve DB credentials:", str(secret_err))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Failed to get DB credentials'})
        }

    try:
        conn = psycopg2.connect(
            host=POSTGRES_DB_HOST,
            dbname=POSTGRES_DB_NAME,
            user=POSTGRES_DB_USER,
            password=POSTGRES_DB_PASSWORD,
            port=POSTGRES_DB_PORT
        )
        cursor = conn.cursor()

        if http_method == 'POST':
            data = json.loads(event['body'])
            user_id = data.get('user_id')
            product_id = data.get('product_id')
            stars = data.get('stars')
            review = data.get('review')

            if not user_id or not product_id or stars is None:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'user_id, product_id, and stars are required'})
                }

            cursor.execute("""
                INSERT INTO product_reviews (user_id, product_id, stars, review)
                VALUES (%s, %s, %s, %s)
                RETURNING review_id
            """, (user_id, product_id, stars, review))

            review_id = cursor.fetchone()[0]
            conn.commit()

            return {
                'statusCode': 201,
                'body': json.dumps({'message': 'Review posted successfully', 'review_id': review_id})
            }

        elif http_method == 'PATCH':
            data = json.loads(event['body'])
            user_id = data.get('user_id')
            product_id = data.get('product_id')
            stars = data.get('stars')
            review = data.get('review')

            if not user_id or not product_id:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'user_id and product_id are required for update'})
                }

            update_fields = []
            params = []

            if stars is not None:
                update_fields.append("stars = %s")
                params.append(stars)
            if review is not None:
                update_fields.append("review = %s")
                params.append(review)

            if not update_fields:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'At least one of stars or review must be provided for update'})
                }

            params.extend([user_id, product_id])

            query = f"""
                UPDATE product_reviews
                SET {', '.join(update_fields)}
                WHERE user_id = %s AND product_id = %s
                RETURNING review_id
            """
            cursor.execute(query, tuple(params))

            if cursor.rowcount == 0:
                return {
                    'statusCode': 404,
                    'body': json.dumps({'error': 'Review not found'})
                }

            review_id = cursor.fetchone()[0]
            conn.commit()

            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'Review updated successfully', 'review_id': review_id})
            }

        elif http_method == 'GET':
            params = event.get('queryStringParameters') or {}
            user_id = params.get('user_id')
            product_id = params.get('product_id')

            if not user_id or not product_id:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'user_id and product_id are required as query parameters'})
                }

            cursor.execute("""
                SELECT review_id, stars, review, created_at
                FROM product_reviews
                WHERE user_id = %s AND product_id = %s
            """, (user_id, product_id))

            result = cursor.fetchone()

            if not result:
                return {
                    'statusCode': 404,
                    'body': json.dumps({'error': 'Review not found'})
                }

            review_id, stars, review, created_at = result
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'review_id': review_id,
                    'stars': float(stars),  # in case it's numeric/decimal
                    'review': review,
                    'created_at': created_at.isoformat() if created_at else None
                })
            }

        else:
            return {
                'statusCode': 405,
                'body': json.dumps({'error': 'Method not allowed'})
            }

    except Exception as e:
        logger.exception("Error handling request")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals():
            conn.close()
