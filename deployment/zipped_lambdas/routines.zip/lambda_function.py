import json
import psycopg2
import logging
import boto3
import base64
from botocore.exceptions import ClientError
from decimal import Decimal

def convert_decimal(obj):
    if isinstance(obj, Decimal):
        return float(obj)
    return obj

def get_secret(secret_name, region_name="us-east-1"):
    client = boto3.client("secretsmanager", region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response["SecretString"])

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')
BUCKET_NAME = 'bucketdermis'
IMAGE_FOLDER = 'scraped_products'

def get_product_image(alt_id):
    try:
        image_key = f"{IMAGE_FOLDER}/{alt_id}.jpg"
        response = s3.get_object(Bucket=BUCKET_NAME, Key=image_key)
        image_bytes = response['Body'].read()
        base64_image = base64.b64encode(image_bytes).decode('utf-8')
        return base64_image
    except ClientError as e:
        logger.warning(f"Image not found for {alt_id}: {str(e)}")
        return None

def lambda_handler(event, context):
    http_method = event.get('requestContext', {}).get('http', {}).get('method', 'POST')

    logger.info(f"Incoming event: {json.dumps(event)}")

    # Get DB credentials
    try:
        secret = get_secret("dermis/dbconfig")
        POSTGRES_DB_HOST = secret["POSTGRES_DB_HOST"]
        POSTGRES_DB_PORT = int(secret.get("POSTGRES_DB_PORT", "5432"))  # Default to 5432 if not set
        POSTGRES_DB_NAME = secret["POSTGRES_DB_NAME"]
        POSTGRES_DB_USER = secret["POSTGRES_DB_USER"]
        POSTGRES_DB_PASSWORD = secret["POSTGRES_DB_PASSWORD"]
    except Exception as secret_err:
        print("Failed to retrieve DB credentials:", str(secret_err))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Failed to get DB credentials'})
        }

    try:
        conn = psycopg2.connect(
            host=POSTGRES_DB_HOST,
            dbname=POSTGRES_DB_NAME,
            user=POSTGRES_DB_USER,
            password=POSTGRES_DB_PASSWORD,
            port=POSTGRES_DB_PORT
        )
        cursor = conn.cursor()

        if http_method == 'POST':
            data = json.loads(event['body'])
            user_id = data.get('user_id')
            name = data.get('name')
            product_names = data.get('product_names')

            logger.info(f"Creating routine for user_id={user_id}, name={name}")

            if not user_id or not name or not product_names:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'user_id, name, and product_names are required'})
                }

            # 🔍 Lookup UUIDs for the given product names
            cursor.execute("""
                SELECT product_id FROM products_scrape
                WHERE name = ANY(%s)
            """, (product_names,))
            product_ids_result = cursor.fetchall()

            if not product_ids_result or len(product_ids_result) != len(product_names):
                return {
                    'statusCode': 404,
                    'body': json.dumps({'error': 'Some product names were not found in the database'})
                }

            # Extract UUIDs from result
            product_ids = [row[0] for row in product_ids_result]

            # Insert routine
            cursor.execute("""
                INSERT INTO routines (user_id, name, product_ids)
                VALUES (%s, %s, %s::uuid[])
                RETURNING routine_id
            """, (user_id, name, product_ids))

            new_routine_id = cursor.fetchone()[0]
            conn.commit()

            return {
                'statusCode': 201,
                'body': json.dumps({'message': 'Routine created successfully', 'routine_id': new_routine_id})
            }

        elif http_method == 'GET':
            user_id = event.get('queryStringParameters', {}).get('user_id')
            if not user_id:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'user_id is required as a query parameter'})
                }

            # Fetch the routine including usage
            cursor.execute("""
                SELECT routine_id, name, product_ids, created_at, usage
                FROM routines
                WHERE user_id = %s
                LIMIT 1
            """, (user_id,))
            result = cursor.fetchone()

            if not result:
                return {
                    'statusCode': 404,
                    'body': json.dumps({'error': 'No routine found for this user'})
                }

            routine_id, name, product_ids, created_at, usage = result
            print(product_ids)

            # Fetch product details
            cursor.execute("""
                SELECT product_id, name, price, ingredients, description, stars, brand, num_reviews,
                       alt_id, limpiar, tratar, proteger
                FROM products_scrape
                WHERE product_id = ANY(%s)
            """, (product_ids,))
            product_rows = cursor.fetchall()
            product_columns = [desc[0] for desc in cursor.description]

            products = []
            for row in product_rows:
                product = {col: convert_decimal(val) for col, val in zip(product_columns, row)}
                alt_id = product.get('alt_id')
                product['image_base64'] = get_product_image(alt_id) if alt_id else None
                products.append(product)

            routine = {
                'routine_id': routine_id,
                'name': name,
                'created_at': created_at.isoformat() if created_at else None,
                'usage': usage,  # Include usage in the response
                'products': products
            }

            return {
                'statusCode': 200,
                'body': json.dumps(routine)
            }

        else:
            return {
                'statusCode': 405,
                'body': json.dumps({'error': 'Method not allowed'})
            }
            

    except Exception as e:
        logger.exception("Error handling request")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals():
            conn.close()