import json
import uuid
import psycopg2
import os
import boto3

def get_secret(secret_name, region_name="us-east-1"):
    client = boto3.client("secretsmanager", region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response["SecretString"])


def lambda_handler(event, context):
    http_method = event.get('requestContext', {}).get('http', {}).get('method', 'POST')

     # Get DB credentials
    try:
        secret = get_secret("dermis/dbconfig")
        POSTGRES_DB_HOST = secret["POSTGRES_DB_HOST"]
        POSTGRES_DB_PORT = int(secret.get("POSTGRES_DB_PORT", "5432"))  # Default to 5432 if not set
        POSTGRES_DB_NAME = secret["POSTGRES_DB_NAME"]
        POSTGRES_DB_USER = secret["POSTGRES_DB_USER"]
        POSTGRES_DB_PASSWORD = secret["POSTGRES_DB_PASSWORD"]
    except Exception as secret_err:
        print("Failed to retrieve DB credentials:", str(secret_err))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Failed to get DB credentials'})
        }
    print("DB credentials retrieved successfully")

    if http_method == 'GET':
        try:
            # Manejo mejorado del body y query parameters
            body = {}
            if event.get('body'):
                if isinstance(event['body'], str):
                    body = json.loads(event['body'])
                else:
                    body = event['body']
            
            query_params = event.get('queryStringParameters', {}) or {}
            skyn_type = query_params.get('skyn_type4') or body.get('skyn_type4')
            
            conn = psycopg2.connect(
                host=POSTGRES_DB_HOST,
                dbname=POSTGRES_DB_NAME,
                user=POSTGRES_DB_USER,
                password=POSTGRES_DB_PASSWORD,
                port=POSTGRES_DB_PORT
            )
            cursor = conn.cursor()
            
            if skyn_type:
                cursor.execute("""
                    SELECT  name, ingredients, product_type 
                    FROM products_book 
                    WHERE skyn_type4 = %s
                """, (skyn_type,))
            else:
                cursor.execute("""
                    SELECT name, ingredients, product_type 
                    FROM products_book
                """)
            
            # Obtener nombres de columnas para hacer el código más claro
            columns = [desc[0] for desc in cursor.description]
            products = [dict(zip(columns, row)) for row in cursor.fetchall()]
            
            cursor.close()
            conn.close()
            
            # Group products by product_type
            grouped_products = {}
            for product in products:
                product_type = product['product_type']
                if product_type not in grouped_products:
                    grouped_products[product_type] = []
                
                # Convertir ingredients de string JSON a lista si es necesario
                if isinstance(product['ingredients'], str):
                    product['ingredients'] = json.loads(product['ingredients'])
                
                grouped_products[product_type].append(product)
            
            return {
                'statusCode': 200,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({
                    'message': 'Products retrieved successfully',
                    'data': grouped_products
                }, default=str)  # default=str para manejar tipos datetime si existen
            }
            
        except Exception as e:
            return {
                'statusCode': 500,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({
                    'error': 'Failed to retrieve products',
                    'details': str(e)
                })
            }

    elif http_method == 'POST':
        print("Processing POST request")
        try:
            # Manejo del body compatible con API Gateway y pruebas directas
            if isinstance(event['body'], str):
                body = json.loads(event['body'])
            else:
                body = event['body']

            # Normalize input
            products = body if isinstance(body, list) else [body]

            print(f"Received {len(products)} products")

            # Assign UUIDs
            rows_to_insert = [
                (
                    str(uuid.uuid4()),
                    p.get('name'),
                    p.get('skyn_type4'),
                    json.dumps(p.get('ingredients', [])),
                    p.get('product_type')
                ) for p in products
            ]


            conn = psycopg2.connect(
                host=POSTGRES_DB_HOST,
                dbname=POSTGRES_DB_NAME,
                user=POSTGRES_DB_USER,
                password=POSTGRES_DB_PASSWORD,
                port=POSTGRES_DB_PORT
            )
            cursor = conn.cursor()

            cursor.executemany("""
                INSERT INTO products_book (product_id, name, skyn_type4, ingredients, product_type)
                VALUES (%s, %s, %s, %s, %s)
            """, rows_to_insert)

            conn.commit()
            cursor.close()
            conn.close()

            return {
                'statusCode': 200,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({
                    'message': f'{len(rows_to_insert)} product(s) registered successfully'
                })
            }

        except Exception as e:
            print(f"Error: {str(e)}")
            return {
                'statusCode': 500,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({
                    'error': 'Internal server error',
                    'details': str(e)
                })
            }

    else:
        return {
            'statusCode': 405,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({
                'error': 'Method not allowed',
                'allowed_methods': ['GET', 'POST']
            })
        }