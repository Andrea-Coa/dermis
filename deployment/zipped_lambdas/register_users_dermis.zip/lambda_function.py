import json
import uuid
import psycopg2
import bcrypt
import boto3

def get_secret(secret_name, region_name="us-east-1"):
    client = boto3.client("secretsmanager", region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response["SecretString"])


def hash_password(password: str) -> str:
    # bcrypt will generate its own salt internally
    hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    return hashed.decode('utf-8')  # Store as string

def lambda_handler(event, context):
    http_method = event.get('requestContext', {}).get('http', {}).get('method', 'POST')

    try:
        secret = get_secret("dermis/dbconfig")
        POSTGRES_DB_HOST = secret["POSTGRES_DB_HOST"]
        POSTGRES_DB_PORT = int(secret.get("POSTGRES_DB_PORT", "5432"))  # Default to 5432 if not set
        POSTGRES_DB_NAME = secret["POSTGRES_DB_NAME"]
        POSTGRES_DB_USER = secret["POSTGRES_DB_USER"]
        POSTGRES_DB_PASSWORD = secret["POSTGRES_DB_PASSWORD"]
    except Exception as secret_err:
        print("Failed to retrieve DB credentials:", str(secret_err))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Failed to get DB credentials'})
        }

    if http_method == 'POST':
        print("entro en post")
        data = json.loads(event['body'])  
        user_id = str(uuid.uuid4())

        # Required fields
        name = data.get('name')
        email = data.get('email')
        age = data.get('age')
        nick_name = data.get('nick_name')
        password = data.get('password')

        if not password:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Password is required'})
            }

        hashed_password = hash_password(password)

        try:
            conn = psycopg2.connect(
                host=POSTGRES_DB_HOST,
                dbname=POSTGRES_DB_NAME,
                user=POSTGRES_DB_USER,
                password=POSTGRES_DB_PASSWORD,
                port=POSTGRES_DB_PORT
            )
            print("se conectó a la bd")
            cursor = conn.cursor()

            # Check if email already exists
            cursor.execute("SELECT 1 FROM users WHERE email = %s", (email,))
            if cursor.fetchone():
                cursor.close()
                conn.close()
                return {
                    'statusCode': 409,
                    'body': json.dumps({'error': 'Email is already registered'})
                }

            cursor.execute("""
                INSERT INTO users (user_id, name, email, age, nick_name, password)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (
                user_id,
                name,
                email,
                age,
                nick_name,
                hashed_password
            ))

            conn.commit()
            cursor.close()
            conn.close()

            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'User registered', 'user_id': user_id})
            }

        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps({'error': str(e)})
            }

    elif http_method == 'PATCH':
        data = json.loads(event['body'])
        user_id = data['_user_id']
        is_sensitive = data.get("is_sensitive")
        skin_type = data['results']['cnn'].get('skinType')
        conditions = data['results']['eff'].get('conditions')

        try:
            conn = psycopg2.connect(
                host=POSTGRES_DB_HOST,
                dbname=POSTGRES_DB_NAME,
                user=POSTGRES_DB_USER,
                password=POSTGRES_DB_PASSWORD,
                port=POSTGRES_DB_PORT
            )
            cursor = conn.cursor()

            # Build UPDATE dynamically to skip None or empty fields
            updates = []
            values = []

            if skin_type:
                updates.append("skyn_type = %s")
                values.append(skin_type)

            if conditions:
                updates.append("skyn_conditions = %s")
                values.append(json.dumps(conditions))

            if is_sensitive is not None:
                updates.append("is_sensitive = %s")
                values.append(is_sensitive)

            if not updates:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'Nothing to update'})
                }

            update_query = f"""
                UPDATE users
                SET {', '.join(updates)}
                WHERE user_id = %s
            """
            values.append(user_id)

            cursor.execute(update_query, values)
            conn.commit()
            cursor.close()
            conn.close()

            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'User updated successfully'})
            }

        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps({'error': str(e)})
            }

    elif http_method == 'GET':
        try:
            user_id = event.get('queryStringParameters', {}).get('user_id')
            if not user_id:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'Missing user_id in query parameters'})
                }

            conn = psycopg2.connect(
                host=POSTGRES_DB_HOST,
                dbname=POSTGRES_DB_NAME,
                user=POSTGRES_DB_USER,
                password=POSTGRES_DB_PASSWORD,
                port=POSTGRES_DB_PORT
            )
            cursor = conn.cursor()

            cursor.execute("""
                SELECT user_id, name, email, age, nick_name, skyn_type, skyn_conditions, is_sensitive
                FROM users
                WHERE user_id = %s
            """, (user_id,))

            row = cursor.fetchone()

            cursor.close()
            conn.close()

            if row:
                keys = ['user_id', 'name', 'email', 'age', 'nick_name', 'skyn_type', 'skyn_conditions', 'is_sensitive']
                user_data = dict(zip(keys, row))
                return {
                    'statusCode': 200,
                    'body': json.dumps(user_data)
                }
            else:
                return {
                    'statusCode': 404,
                    'body': json.dumps({'error': 'User not found'})
                }

        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps({'error': str(e)})
            }

    else:
        return {
            'statusCode': 405,
            'body': json.dumps({'error': 'Method not allowed'})
        }
