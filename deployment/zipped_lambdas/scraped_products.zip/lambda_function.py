import json
import psycopg2
import boto3
import base64
from botocore.exceptions import ClientError
from decimal import Decimal

s3 = boto3.client('s3')
BUCKET_NAME = 'bucketdermis'
IMAGE_FOLDER = 'scraped_products'

def get_secret(secret_name, region_name="us-east-1"):
    client = boto3.client("secretsmanager", region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response["SecretString"])


def convert_decimal(obj):
    if isinstance(obj, Decimal):
        return float(obj)
    return obj

def get_product_image(alt_id):
    try:
        image_key = f"{IMAGE_FOLDER}/{alt_id}.jpg"
        response = s3.get_object(Bucket=BUCKET_NAME, Key=image_key)
        image_bytes = response['Body'].read()
        base64_image = base64.b64encode(image_bytes).decode('utf-8')
        return base64_image
    except ClientError as e:
        print(f"Image not found for {alt_id}: {str(e)}")
        return None

def lambda_handler(event, context):
    http_method = event.get('requestContext', {}).get('http', {}).get('method', 'POST')
    # Get DB credentials
    try:
        secret = get_secret("dermis/dbconfig")
        POSTGRES_DB_HOST = secret["POSTGRES_DB_HOST"]
        POSTGRES_DB_PORT = int(secret.get("POSTGRES_DB_PORT", "5432"))  # Default to 5432 if not set
        POSTGRES_DB_NAME = secret["POSTGRES_DB_NAME"]
        POSTGRES_DB_USER = secret["POSTGRES_DB_USER"]
        POSTGRES_DB_PASSWORD = secret["POSTGRES_DB_PASSWORD"]
    except Exception as secret_err:
        print("Failed to retrieve DB credentials:", str(secret_err))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Failed to get DB credentials'})
        }

    if http_method == 'GET':
        try:
            params = event.get('queryStringParameters') or {}

            conn = psycopg2.connect(
                host=POSTGRES_DB_HOST,
                dbname=POSTGRES_DB_NAME,
                user=POSTGRES_DB_USER,
                password=POSTGRES_DB_PASSWORD,
                port=POSTGRES_DB_PORT
            )
            cursor = conn.cursor()

            if 'id' in params:
                cursor.execute("""
                    SELECT * FROM products_scrape
                    WHERE product_id = %s
                """, (params['id'],))
            elif 'name' in params:
                cursor.execute("""
                    SELECT * FROM products_scrape
                    WHERE name = %s
                """, (params['name'],))
            else:
                return {
                    'statusCode': 400,
                    'headers': {'Content-Type': 'application/json'},
                    'body': json.dumps({'error': 'Missing "id" or "name" query parameter'})
                }

            row = cursor.fetchone()
            if not row:
                return {
                    'statusCode': 404,
                    'headers': {'Content-Type': 'application/json'},
                    'body': json.dumps({'error': 'Product not found'})
                }

            columns = [desc[0] for desc in cursor.description]
            product = dict(zip(columns, row))

            # Convert Decimal fields to float
            product = {k: convert_decimal(v) for k, v in product.items()}

            alt_id = product.get('alt_id')
            if alt_id:
                image_data = get_product_image(alt_id)
                product['image_base64'] = image_data

            cursor.close()
            conn.close()

            return {
                'statusCode': 200,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps(product)
            }

        except Exception as e:
            print(f"Error: {str(e)}")
            return {
                'statusCode': 500,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({
                    'error': 'Failed to retrieve product',
                    'details': str(e)
                })
            }

    elif http_method == 'POST':
        try:
            if isinstance(event['body'], str):
                body = json.loads(event['body'])
            else:
                body = event['body']

            products = body if isinstance(body, list) else [body]

            rows_to_insert = [
                (
                    p.get('name'),
                    p.get('price'),
                    json.dumps(p.get('ingredients', [])),
                    p.get('description'),
                    p.get('image'),
                    p.get('stars'),
                    p.get('alt_id'),
                    p.get('brand'),
                    p.get('limpiar', False),
                    p.get('tratar', False),
                    p.get('proteger', False)
                )
                for p in products
            ]

            conn = psycopg2.connect(
                host=POSTGRES_DB_HOST,
                dbname=POSTGRES_DB_NAME,
                user=POSTGRES_DB_USER,
                password=POSTGRES_DB_PASSWORD,
                port=POSTGRES_DB_PORT
            )
            cursor = conn.cursor()

            cursor.executemany("""
                INSERT INTO products_scrape (
                    name, price, ingredients,
                    description, image, stars,
                    alt_id, brand,
                    limpiar, tratar, proteger
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, rows_to_insert)

            conn.commit()
            cursor.close()
            conn.close()

            return {
                'statusCode': 200,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({
                    'message': f'{len(rows_to_insert)} product(s) inserted successfully'
                })
            }

        except Exception as e:
            return {
                'statusCode': 500,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({
                    'error': 'Internal server error',
                    'details': str(e)
                })
            }

    else:
        return {
            'statusCode': 405,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({
                'error': 'Method not allowed',
                'allowed_methods': ['POST', 'GET']
            })
        }
