import json
import psycopg2
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    method = event.get('requestContext', {}).get('http', {}).get('method', '')
    logger.info(f"Received {method} request: {json.dumps(event)}")

    try:
        conn = psycopg2.connect(
            host='52.207.203.29',
            dbname='dermis_users',
            user='dermis_user',
            password='jacdermisapp',
            port=5432
        )
        cursor = conn.cursor()

        if method == 'POST':
            data = json.loads(event.get('body', '{}'))
            user_id = data.get('user_id')
            routine_id = data.get('routine_id')
            rating = data.get('rating')
            message = data.get('message', '')

            if not all([user_id, routine_id, rating]):
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'user_id, routine_id, and rating are required'})
                }

            cursor.execute("""
                INSERT INTO feedbacks (user_id, routine_id, rating, message)
                VALUES (%s, %s, %s, %s)
                RETURNING feedback_id, created_at
            """, (user_id, routine_id, rating, message))

            feedback_id, created_at = cursor.fetchone()
            conn.commit()

            return {
                'statusCode': 201,
                'body': json.dumps({
                    'message': 'Feedback created successfully',
                    'feedback_id': feedback_id,
                    'created_at': created_at.isoformat()
                })
            }

        elif method == 'PATCH':
            data = json.loads(event.get('body', '{}'))
            user_id = data.get('user_id')
            routine_id = data.get('routine_id')
            rating = data.get('rating')
            message = data.get('message')

            if not all([user_id, routine_id]):
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'user_id and routine_id are required'})
                }

            if rating is None and message is None:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'At least one of rating or message must be provided'})
                }

            update_fields = []
            values = []

            if rating is not None:
                update_fields.append("rating = %s")
                values.append(rating)
            if message is not None:
                update_fields.append("message = %s")
                values.append(message)

            values.extend([user_id, routine_id])

            query = f"""
                UPDATE feedbacks
                SET {', '.join(update_fields)}
                WHERE user_id = %s AND routine_id = %s
                RETURNING feedback_id
            """

            cursor.execute(query, values)
            result = cursor.fetchone()

            if not result:
                return {
                    'statusCode': 404,
                    'body': json.dumps({'error': 'Feedback not found for given user_id and routine_id'})
                }

            conn.commit()
            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'Feedback updated successfully'})
            }

        elif method == 'GET':
            routine_id = event.get('queryStringParameters', {}).get('routine_id')
            if not routine_id:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'routine_id is required as a query parameter'})
                }

            cursor.execute("""
                SELECT feedback_id, user_id, rating, message, created_at, status, feedback_type
                FROM feedbacks
                WHERE routine_id = %s
                LIMIT 1
            """, (routine_id,))
            row = cursor.fetchone()

            if not row:
                return {
                    'statusCode': 404,
                    'body': json.dumps({'error': 'Feedback not found for this routine_id'})
                }

            feedback = {
                'feedback_id': row[0],
                'user_id': row[1],
                'rating': row[2],
                'message': row[3],
                'created_at': row[4].isoformat() if row[4] else None,
                'status': row[5],
                'feedback_type': row[6]
            }

            return {
                'statusCode': 200,
                'body': json.dumps(feedback)
            }

        else:
            return {
                'statusCode': 405,
                'body': json.dumps({'error': 'Method not allowed'})
            }

    except Exception as e:
        logger.exception("Error processing feedback request")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals():
            conn.close()
