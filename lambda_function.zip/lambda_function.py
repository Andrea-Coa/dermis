import json
import uuid
import psycopg2

def lambda_handler(event, context):
    data = json.loads(event['body'])
    user_id = str(uuid.uuid4())

    try:
        conn = psycopg2.connect(
            host='3.82.196.32',
            dbname='dermis_users',
            user='dermis_user',
            password='jacdermisapp',
            port=5432
        )
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO users (user_id, name, email, age,nick_name, skyn_type, skyn_conditions)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (
            user_id,
            data.get('name'),
            data.get('email'),
            data.get('age'),
            data.get('nick_name'),
            None,
            json.dumps([])
        ))

        conn.commit()
        cursor.close()
        conn.close()

        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'User registered', 'user_id': user_id})
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
